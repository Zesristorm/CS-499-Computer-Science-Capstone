TASKS = {
    "hall of champions": {
        "name": "The Knight's Challenge",
        "reward": "poisoned dagger",
        "description": (
            "An enchanted knight guards the Poisoned Dagger. "
            "Its shield displays a riddle that must be answered."
        ),
    },
    "moonflower conservatory": {
        "name": "The Moonflower Trial",
        "reward": "enchanted amulet",
        "description": (
            "Three moonflowers bloom beneath enchanted glass. "
            "A riddle appears across the conservatory dome."
        ),
    },
    "imperial wardrobe": {
        "name": "The Royal Disguise",
        "reward": "royal gown",
        "description": (
            "The Royal Gown rests inside a sealed imperial wardrobe. "
            "Golden thread forms a riddle across its doors."
        ),
    },
    "imperial archives": {
        "name": "The Stolen Authority",
        "reward": "crown sigil",
        "description": (
            "The Crown Sigil rests inside a sealed archive case. "
            "The case is protected by a riddle about authority."
        ),
    },
    "sacred library": {
        "name": "The Forbidden Grimoire",
        "reward": "grimoire of restoration",
        "description": (
            "The Grimoire of Restoration is sealed by "
            "a riddle about healing magic."
        ),
    },
}


def run_room_task(room_name, completed_tasks):
    if room_name in completed_tasks:
        print("You already completed the challenge in this room.")
        return True

    task_functions = {
        "hall of champions": knight_challenge,
        "moonflower conservatory": moonflower_trial,
        "imperial wardrobe": wardrobe_challenge,
        "imperial archives": archive_challenge,
        "sacred library": library_challenge,
    }

    task_function = task_functions.get(room_name)
    if task_function is None:
        print("There is no challenge in this room.")
        return False

    print("\n" + "=" * 50)
    print(TASKS[room_name]["name"])
    print("=" * 50)
    print(TASKS[room_name]["description"])

    completed = task_function()
    if completed:
        completed_tasks.add(room_name)
        print("\nChallenge completed.")
    else:
        print("\nYou did not complete the challenge. You may try again.")

    return completed


def knight_challenge():
    print("\nThe enchanted knight lowers its blade.")
    print("Words glow across its shield:")
    print()
    print('"I have a point but cannot think.')
    print("I have an edge but cannot speak.")
    print('In a warrior\'s hand, I may decide a battle. What am I?"')
    print()
    print("1. A crown")
    print("2. A blade")
    print("3. A shield")
    print("4. A banner")

    choice = get_number_choice(1, 4)

    if choice == 2:
        print("\nThe knight accepts your answer.")
        print("Its enchantment fades, revealing the Poisoned Dagger.")
        return True

    print("\nThe knight raises its shield and blocks your path.")
    return False


def moonflower_trial():
    print("\nThree moonflowers turn toward you.")
    print("Silver writing appears across the glass dome:")
    print()
    print('"I brighten the night but produce no flame.')
    print("I change my shape but keep the same name.")
    print('The flowers turn toward me as I cross the sky. What am I?"')
    print()
    print("1. The moon")
    print("2. A lantern")
    print("3. A star")
    print("4. The sun")

    choice = get_number_choice(1, 4)

    if choice == 1:
        print("\nThe moonflowers bloom at once.")
        print("The Enchanted Amulet appears among their silver petals.")
        return True

    print("\nThe moonflowers close and turn away from you.")
    return False


def wardrobe_challenge():
    print("\nGolden thread moves across the wardrobe doors:")
    print()
    print('"I may be worn but I am not clothing.')
    print("I may be inherited but I am not gold.")
    print('I can open doors without touching them. What am I?"')
    print()
    print("1. A title")
    print("2. A necklace")
    print("3. A key")
    print("4. A crown")

    choice = get_number_choice(1, 4)

    if choice == 1:
        print("\nThe wardrobe accepts your answer.")
        print("The doors open and reveal the Royal Gown.")
        return True

    print("\nThe golden thread unravels and the wardrobe remains sealed.")
    return False


def archive_challenge():
    print("\nThe archive case glows with golden light.")
    print("A question appears across the sealed glass:")
    print()
    print('"I can command without a voice.')
    print("I can move armies without taking a step.")
    print("I am powerless when no one obeys me.")
    print('What am I?"')
    print()
    print("1. Authority")
    print("2. Wealth")
    print("3. A crown")
    print("4. A sword")

    choice = get_number_choice(1, 4)

    if choice == 1:
        print("\nThe archive accepts your answer.")
        print("The sealed case opens and reveals the Crown Sigil.")
        return True

    print("\nThe archive case remains sealed.")

    if choice == 2:
        print('"Wealth may purchase loyalty, but it cannot guarantee obedience."')
    elif choice == 3:
        print('"A crown is only a symbol of power."')
    else:
        print('"A sword may enforce a command, but it does not create authority."')

    return False


def library_challenge():
    print("\nSilver letters appear across the sealed grimoire:")
    print()
    print('"I return what has been lost,')
    print("but I cannot exceed what once was whole.")
    print('I close wounds without turning back time. What am I?"')
    print()
    print("1. Time")
    print("2. Healing magic")
    print("3. Memory")
    print("4. Strength")

    choice = get_number_choice(1, 4)

    if choice == 2:
        print("\nThe grimoire accepts your answer.")
        print("Its cover opens, revealing the Restoration spell.")
        return True

    print("\nThe grimoire remains sealed.")
    return False


def get_number_choice(minimum, maximum):
    while True:
        choice = input("Choose an option: ").strip()
        try:
            choice_number = int(choice)
        except ValueError:
            print(f"Enter a number from {minimum} through {maximum}.")
            continue

        if minimum <= choice_number <= maximum:
            return choice_number

        print(f"Enter a number from {minimum} through {maximum}.")