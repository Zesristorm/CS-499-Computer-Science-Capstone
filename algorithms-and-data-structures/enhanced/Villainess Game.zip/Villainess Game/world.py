ROOMS = {
    "imperial gallery": {
        "north": "moonflower conservatory",
        "west": "hall of champions",
        "east": "imperial wardrobe",
    },
    "hall of champions": {
        "east": "imperial gallery",
        "south": "alchemy atelier",
    },
    "moonflower conservatory": {
        "south": "imperial gallery",
    },
    "imperial wardrobe": {
        "west": "imperial gallery",
        "south": "imperial archives",
    },
    "alchemy atelier": {
        "north": "hall of champions",
        "east": "sacred library",
        "special": "potion choice",
    },
    "sacred library": {
        "west": "alchemy atelier",
        "east": "imperial archives",
        "south": "grand throne room",
    },
    "imperial archives": {
        "north": "imperial wardrobe",
        "west": "sacred library",
    },
    "grand throne room": {
        "north": "sacred library",
        "boss": "saintess",
    },
}

VALID_DIRECTIONS = {"north", "south", "east", "west"}


def process_move(current_room, direction, inventory):
    direction = direction.strip().lower()
    room = ROOMS[current_room]

    if direction not in VALID_DIRECTIONS:
        print("Use north, south, east, or west.")
        return current_room

    if direction not in room:
        print("You cannot go that way.")
        return current_room

    next_room = room[direction]

    if next_room == "grand throne room" and "crown sigil" not in inventory:
        print("\nA holy seal blocks the Grand Throne Room.")
        print("You need the Crown Sigil to pass through it.")
        return current_room

    return next_room