ITEMS = {
    "poisoned dagger": {
        "category": "weapon",
        "description": (
            "Provides a normal attack and a powerful Venomous Strike that "
            "applies poison for two turns."
        ),
    },
    "royal gown": {
        "category": "armor",
        "description": (
            "Absorbs incoming damage before the villainess loses health."
        ),
    },
    "enchanted amulet": {
        "category": "accessory",
        "description": (
            "Strengthens one attack, dodge, or healing action before entering cooldown."
        ),
    },
    "crown sigil": {
        "category": "key item",
        "description": "Bypasses the holy seal protecting the Grand Throne Room.",
    },
    "grimoire of restoration": {
        "category": "grimoire",
        "description": "Restores health and then enters cooldown.",
    },
}

POTIONS = {
    "health potion": {
        "effect": "heal",
        "value": 35,
        "description": "Restores 35 health once.",
    },
    "defense potion": {
        "effect": "defense",
        "value": 0.40,
        "duration": 3,
        "description": "Reduces incoming damage by 40% for three enemy attacks.",
    },
    "poison potion": {
        "effect": "poison",
        "value": 4,
        "duration": 2,
        "description": "Strengthens the dagger's next poison effect.",
    },
}