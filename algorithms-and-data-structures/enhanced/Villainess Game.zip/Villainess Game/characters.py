class Player:

    def __init__(self):
        # Core health
        self.max_health = 100
        self.health = self.max_health
        self.alive = True

        # Royal Gown protection
        self.max_gown_protection = 40
        self.gown_protection = self.max_gown_protection
        self.gown_broken = False

        # Equipment and inventory
        self.inventory = set()
        self.completed_tasks = set()
        self.selected_potion = None
        self.potion_used = False

        # Cooldowns
        self.dagger_special_cooldown = 0
        self.amulet_cooldown = 0
        self.grimoire_cooldown = 0

        # Temporary effects
        self.amulet_active = False
        self.amulet_effect = None
        self.defense_potion_turns = 0
        self.poison_potion_active = False

        # Battle stats
        self.successful_dodges = 0
        self.failed_dodges = 0
        self.damage_dealt = 0
        self.damage_taken = 0
        self.healing_received = 0

    def has_item(self, item_name):
        return item_name.lower() in self.inventory

    def add_item(self, item_name):
        self.inventory.add(item_name.lower())

    def choose_potion(self, potion_name):
        valid_potions = {
            "health potion",
            "defense potion",
            "poison potion"
        }

        potion_name = potion_name.lower()

        if potion_name not in valid_potions:
            return False

        self.selected_potion = potion_name
        self.potion_used = False
        return True

    def take_damage(self, damage):
        damage = max(0, int(damage))

        if self.defense_potion_turns > 0:
            damage = round(damage * 0.60)

        if not self.gown_broken and self.gown_protection > 0:
            absorbed_damage = min(self.gown_protection, damage)
            self.gown_protection -= absorbed_damage
            damage -= absorbed_damage

            if self.gown_protection <= 0:
                self.gown_protection = 0
                self.gown_broken = True

        if damage > 0:
            self.health -= damage
            self.damage_taken += damage

        if self.health <= 0:
            self.health = 0
            self.alive = False

        return damage

    def heal(self, amount):
        if not self.alive:
            return 0

        amount = max(0, int(amount))
        previous_health = self.health

        self.health = min(self.max_health, self.health + amount)
        healed_amount = self.health - previous_health
        self.healing_received += healed_amount

        return healed_amount

    def activate_amulet(self, effect):
        valid_effects = {"attack", "dodge", "healing"}

        if self.amulet_cooldown > 0:
            return False

        if effect not in valid_effects:
            return False

        self.amulet_active = True
        self.amulet_effect = effect
        self.amulet_cooldown = 4
        return True

    def consume_amulet_effect(self, effect):
        if not self.amulet_active:
            return False

        if self.amulet_effect != effect:
            return False

        self.amulet_active = False
        self.amulet_effect = None
        return True

    def use_potion(self):
        if self.selected_potion is None:
            return "You did not bring a potion."

        if self.potion_used:
            return "Your potion has already been used."

        self.potion_used = True

        if self.selected_potion == "health potion":
            healed = self.heal(35)
            return f"The Health Potion restored {healed} health."

        if self.selected_potion == "defense potion":
            self.defense_potion_turns = 3
            return (
                "The Defense Potion will reduce incoming damage "
                "for the next 3 damaging attacks."
            )

        if self.selected_potion == "poison potion":
            self.poison_potion_active = True
            return (
                "The Poison Potion will strengthen the next poison "
                "effect applied by the Poisoned Dagger."
            )

        return "The potion had no effect."

    def use_grimoire(self):
        if self.grimoire_cooldown > 0:
            return 0

        healing_amount = 24

        if self.consume_amulet_effect("healing"):
            healing_amount = round(healing_amount * 1.5)

        healed = self.heal(healing_amount)
        self.grimoire_cooldown = 4

        return healed

    def start_dagger_special_cooldown(self):
        self.dagger_special_cooldown = 3

    def reduce_cooldowns(self):
        if self.dagger_special_cooldown > 0:
            self.dagger_special_cooldown -= 1

        if self.amulet_cooldown > 0:
            self.amulet_cooldown -= 1

        if self.grimoire_cooldown > 0:
            self.grimoire_cooldown -= 1

    def reduce_temporary_effects(self):
        if self.defense_potion_turns > 0:
            self.defense_potion_turns -= 1

    def record_dodge(self, successful):
        if successful:
            self.successful_dodges += 1
        else:
            self.failed_dodges += 1

    def record_damage_dealt(self, damage):
        self.damage_dealt += max(0, int(damage))

    def get_status(self):
        return {
            "health": self.health,
            "max_health": self.max_health,
            "gown_protection": self.gown_protection,
            "max_gown_protection": self.max_gown_protection,
            "gown_broken": self.gown_broken,
            "dagger_special_cooldown": self.dagger_special_cooldown,
            "amulet_cooldown": self.amulet_cooldown,
            "grimoire_cooldown": self.grimoire_cooldown,
            "selected_potion": self.selected_potion,
            "potion_used": self.potion_used,
            "defense_potion_turns": self.defense_potion_turns
        }


class Saintess:

    def __init__(self):
        # Core health
        self.max_health = 140
        self.health = self.max_health
        self.alive = True

        # Poison status
        self.poison_turns = 0
        self.poison_damage = 0

        # Defensive and healing behavior
        self.barrier_active = False
        self.barrier_reduction = 0.35
        self.heal_uses_remaining = 1
        self.purify_uses_remaining = 1

        # Battle phase
        self.phase = 1
        self.next_attack = None
        self.last_action_type = None

        # Battle stats
        self.damage_dealt = 0
        self.damage_taken = 0
        self.healing_received = 0

        # Attack definitions
        self.abilities = {
            "holy bolt": {
                "type": "targeted",
                "damage_min": 10,
                "damage_max": 14,
                "dodge_chance_modifier": 0
            },
            "radiant spear": {
                "type": "targeted",
                "damage_min": 16,
                "damage_max": 20,
                "dodge_chance_modifier": -10
            },
            "divine wave": {
                "type": "wide",
                "damage_min": 14,
                "damage_max": 18,
                "dodge_chance_modifier": -25
            },
            "judgment light": {
                "type": "powerful",
                "damage_min": 20,
                "damage_max": 25,
                "dodge_chance_modifier": -15
            }
        }

    def take_damage(self, damage):
        damage = max(0, int(damage))

        if self.barrier_active:
            damage = round(damage * (1 - self.barrier_reduction))
            self.barrier_active = False

        self.health -= damage
        self.damage_taken += damage

        if self.health <= 0:
            self.health = 0
            self.alive = False

        self.update_phase()
        return damage

    def heal(self, amount):
        if not self.alive:
            return 0

        amount = max(0, int(amount))
        previous_health = self.health

        self.health = min(self.max_health, self.health + amount)
        healed_amount = self.health - previous_health
        self.healing_received += healed_amount

        self.update_phase()
        return healed_amount

    def apply_poison(self, damage, duration=2):
        self.poison_damage = max(0, int(damage))
        self.poison_turns = max(0, int(duration))

    def process_poison(self):
        if self.poison_turns <= 0 or not self.alive:
            return 0

        damage = self.poison_damage
        self.health -= damage
        self.damage_taken += damage
        self.poison_turns -= 1

        if self.poison_turns == 0:
            self.poison_damage = 0

        if self.health <= 0:
            self.health = 0
            self.alive = False

        self.update_phase()
        return damage

    def purify(self):
        if self.purify_uses_remaining <= 0:
            return False

        if self.poison_turns <= 0:
            return False

        self.poison_turns = 0
        self.poison_damage = 0
        self.purify_uses_remaining -= 1
        return True

    def activate_barrier(self):
        self.barrier_active = True

    def use_heal(self):
        if self.heal_uses_remaining <= 0:
            return 0

        healed = self.heal(16)

        if healed > 0:
            self.heal_uses_remaining -= 1

        return healed

    def update_phase(self):
        health_percentage = self.health / self.max_health

        if health_percentage > 0.66:
            self.phase = 1
        elif health_percentage > 0.33:
            self.phase = 2
        else:
            self.phase = 3

    def record_damage_dealt(self, damage):
        self.damage_dealt += max(0, int(damage))

    def get_status(self):
        return {
            "health": self.health,
            "max_health": self.max_health,
            "phase": self.phase,
            "poison_turns": self.poison_turns,
            "poison_damage": self.poison_damage,
            "barrier_active": self.barrier_active,
            "heal_uses_remaining": self.heal_uses_remaining,
            "purify_uses_remaining": self.purify_uses_remaining
        }