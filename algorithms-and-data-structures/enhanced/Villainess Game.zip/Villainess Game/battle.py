import random

from characters import Player, Saintess

# Battle balance settings

NORMAL_ATTACK_MIN = 9
NORMAL_ATTACK_MAX = 13

SPECIAL_ATTACK_MIN = 15
SPECIAL_ATTACK_MAX = 19

NORMAL_POISON_DAMAGE = 5
ENHANCED_POISON_DAMAGE = 9
POISON_DURATION = 2

BASE_DODGE_CHANCE = 60
AMULET_DODGE_CHANCE = 95
AMULET_ATTACK_MULTIPLIER = 1.5
DODGE_COUNTER_MIN = 4
DODGE_COUNTER_MAX = 6


def display_battle_intro():
    print("\n" + "=" * 55)
    print("FINAL BATTLE: THE VILLAINESS VS. THE SAINTESS")
    print("=" * 55)
    print(
        "The Crown Sigil breaks the holy seal surrounding the throne room."
    )
    print(
        "The Saintess turns toward you as divine light gathers around her."
    )
    print(
        '"You have gone far enough," she says. '
        '"I will not give up the Emperor to you."'
    )
    print(
        'You draw your dagger and smile. '
        '"Then you should have understood that he is mine!"'
    )
    print("=" * 55)


def display_battle_status(player, saintess, turn_number):
    print("\n" + "-" * 55)
    print(f"Turn {turn_number}")
    print("-" * 55)

    print(
        f"Villainess Health: {player.health}/{player.max_health}"
    )

    if player.gown_broken:
        print("Royal Gown Protection: BROKEN")
    else:
        print(
            "Royal Gown Protection: "
            f"{player.gown_protection}/{player.max_gown_protection}"
        )

    print(
        f"Saintess Health: {saintess.health}/{saintess.max_health}"
    )
    print(f"Saintess Phase: {saintess.phase}")

    if saintess.poison_turns > 0:
        print(
            f"Saintess Poison: {saintess.poison_turns} turn(s) remaining"
        )

    if saintess.barrier_active:
        print("Saintess Barrier: ACTIVE")

    print("\nCooldowns:")
    print(
        "Venomous Strike: "
        f"{format_cooldown(player.dagger_special_cooldown)}"
    )
    print(
        "Enchanted Amulet: "
        f"{format_cooldown(player.amulet_cooldown)}"
    )
    print(
        "Grimoire of Restoration: "
        f"{format_cooldown(player.grimoire_cooldown)}"
    )

    if player.amulet_active:
        print(
            "Amulet Enhancement Prepared: "
            f"{player.amulet_effect.title()}"
        )

    if player.defense_potion_turns > 0:
        print(
            "Defense Potion: "
            f"{player.defense_potion_turns} protected hit(s) remaining"
        )

    if player.selected_potion:
        potion_status = (
            "USED" if player.potion_used else "AVAILABLE"
        )
        print(
            f"Chosen Potion: {player.selected_potion.title()} "
            f"({potion_status})"
        )


def format_cooldown(cooldown):
    if cooldown <= 0:
        return "READY"

    return f"{cooldown} turn(s)"


def roll_damage(minimum, maximum):
    return random.randint(minimum, maximum)


def calculate_dodge_chance(player, saintess_attack):
    dodge_chance = BASE_DODGE_CHANCE

    dodge_chance += saintess_attack.get(
        "dodge_chance_modifier",
        0
    )

    if player.consume_amulet_effect("dodge"):
        dodge_chance = AMULET_DODGE_CHANCE
        print(
            "The Enchanted Amulet sharpens your reflexes."
        )

    return max(10, min(95, dodge_chance))


def attempt_dodge(player, saintess_attack):
    dodge_chance = calculate_dodge_chance(
        player,
        saintess_attack
    )

    roll = random.randint(1, 100)
    successful = roll <= dodge_chance

    player.record_dodge(successful)

    print(
        f"You attempt to dodge. "
        f"Success chance: {dodge_chance}%."
    )

    if successful:
        print(
            "You slip away just before the holy attack reaches you."
        )
    else:
        print(
            "The attack catches you before you can get clear."
        )

    return successful


def apply_player_attack(player, saintess, damage):
    if player.consume_amulet_effect("attack"):
        damage = round(
            damage * AMULET_ATTACK_MULTIPLIER
        )
        print(
            "The Enchanted Amulet empowers your attack."
        )

    actual_damage = saintess.take_damage(damage)
    player.record_damage_dealt(actual_damage)

    if actual_damage < damage:
        print(
            f"The Saintess's barrier reduces the damage to "
            f"{actual_damage}."
        )
    else:
        print(
            f"The Saintess suffers {actual_damage} damage."
        )

    return actual_damage


def use_normal_attack(player, saintess):
    if player.has_item("poisoned dagger"):
        damage = roll_damage(
            NORMAL_ATTACK_MIN,
            NORMAL_ATTACK_MAX
        )
        print(
            "You strike with the Poisoned Dagger."
        )
    else:
        damage = roll_damage(4, 7)
        print(
            "Without the dagger, you strike as best you can."
        )

    apply_player_attack(
        player,
        saintess,
        damage
    )


def use_special_attack(player, saintess):
    if not player.has_item("poisoned dagger"):
        print(
            "Venomous Strike requires the Poisoned Dagger."
        )
        return False

    if player.dagger_special_cooldown > 0:
        print(
            "Venomous Strike will be ready again soon."
        )
        return False

    damage = roll_damage(
        SPECIAL_ATTACK_MIN,
        SPECIAL_ATTACK_MAX
    )

    print(
        "You use Venomous Strike with the Poisoned Dagger."
    )

    apply_player_attack(
        player,
        saintess,
        damage
    )

    if not saintess.alive:
        return True

    poison_damage = NORMAL_POISON_DAMAGE

    if player.poison_potion_active:
        poison_damage = ENHANCED_POISON_DAMAGE
        player.poison_potion_active = False

        print(
            "The Poison Potion strengthens the dagger's venom."
        )

    saintess.apply_poison(
        poison_damage,
        POISON_DURATION
    )

    print(
        f"The Saintess is poisoned for {POISON_DURATION} turns."
    )

    player.start_dagger_special_cooldown()
    return True


def activate_amulet(player):
    if not player.has_item("enchanted amulet"):
        print(
            "The Enchanted Amulet is not in your inventory."
        )
        return False

    if player.amulet_cooldown > 0:
        print(
            "The Enchanted Amulet will be ready again soon."
        )
        return False

    if player.amulet_active:
        print(
            "The Enchanted Amulet is already prepared for your next action."
        )
        return False

    print("\nChoose an action for the amulet to strengthen:")
    print("1. Attack")
    print("2. Dodge")
    print("3. Healing")
    print("4. Cancel")

    choice = input("Choose an amulet effect: ").strip()

    effects = {
        "1": "attack",
        "2": "dodge",
        "3": "healing"
    }

    if choice == "4":
        print(
            "You leave the amulet untouched for now."
        )
        return False

    effect = effects.get(choice)

    if effect is None:
        print(
            "Choose Attack, Dodge, Healing, or Cancel."
        )
        return False

    player.activate_amulet(effect)

    print(
        f"The Enchanted Amulet will strengthen your "
        f"next {effect} action."
    )
    return True


def use_player_potion(player):
    if player.selected_potion is None:
        print(
            "You do not have a potion with you."
        )
        return False

    if player.potion_used:
        print(
            "Your potion has already been used."
        )
        return False

    result = player.use_potion()
    print(result)
    return True


def use_grimoire(player):
    if not player.has_item("grimoire of restoration"):
        print(
            "The Grimoire of Restoration is not in your inventory."
        )
        return False

    if player.grimoire_cooldown > 0:
        print(
            "The Grimoire of Restoration will be ready again soon."
        )
        return False

    if player.health >= player.max_health:
        print(
            "You are already at full health."
        )
        return False

    healed = player.use_grimoire()

    print(
        f"The Grimoire of Restoration restores "
        f"{healed} health."
    )
    return True


def display_player_actions(player):
    if not player.has_item("poisoned dagger"):
        venom = "NOT OWNED"
    elif player.dagger_special_cooldown <= 0:
        venom = "READY"
    else:
        venom = f"Cooldown: {player.dagger_special_cooldown}"

    if not player.has_item("enchanted amulet"):
        amulet = "NOT OWNED"
    elif player.amulet_cooldown <= 0:
        amulet = "READY"
    else:
        amulet = f"Cooldown: {player.amulet_cooldown}"

    if not player.has_item("grimoire of restoration"):
        restore = "NOT OWNED"
    elif player.grimoire_cooldown <= 0:
        restore = "READY"
    else:
        restore = f"Cooldown: {player.grimoire_cooldown}"

    if player.selected_potion is None:
        potion = "NONE"
    elif player.potion_used:
        potion = "USED"
    else:
        potion = "READY"

    print("\nChoose your action:")
    print("1. Attack")
    print(f"2. Venom ({venom})")
    print("3. Dodge")
    print(f"4. Amulet ({amulet})")
    print(f"5. Potion ({potion})")
    print(f"6. Restore ({restore})")


def get_player_action():
    valid_choices = {"1", "2", "3", "4", "5", "6"}

    while True:
        choice = input("Enter your choice: ").strip()

        if choice in valid_choices:
            return choice

        print(
            "Choose a number from 1 through 6."
        )

def choose_saintess_action(saintess):
    if (
        saintess.health <= saintess.max_health * 0.45
        and saintess.heal_uses_remaining > 0
        and saintess.last_action_type not in {"heal", "barrier"}
    ):
        return {
            "name": "Sacred Restoration",
            "type": "heal"
        }

    if (
        saintess.poison_turns > 0
        and saintess.purify_uses_remaining > 0
        and random.randint(1, 100) <= 35
    ):
        return {
            "name": "Purify",
            "type": "purify"
        }

    if (
        saintess.phase >= 2
        and not saintess.barrier_active
        and saintess.last_action_type not in {"heal", "barrier"}
        and random.randint(1, 100) <= 20
    ):
        return {
            "name": "Divine Barrier",
            "type": "barrier"
        }

    if saintess.phase == 1:
        attack_names = [
            "holy bolt",
            "holy bolt",
            "radiant spear"
        ]

    elif saintess.phase == 2:
        attack_names = [
            "holy bolt",
            "radiant spear",
            "divine wave"
        ]

    else:
        attack_names = [
            "radiant spear",
            "divine wave",
            "judgment light"
        ]

    attack_name = random.choice(attack_names)
    attack = saintess.abilities[attack_name].copy()
    attack["name"] = attack_name.title()

    return attack


def telegraph_saintess_action(action):
    action_name = action["name"]

    messages = {
        "Holy Bolt": (
            "The Saintess is charging Holy Bolt for next turn."
        ),
        "Radiant Spear": (
            "The Saintess is preparing Radiant Spear for next turn."
        ),
        "Divine Wave": (
            "The Saintess is preparing Divine Wave for next turn."
        ),
        "Judgment Light": (
            "The Saintess is charging Judgment Light for next turn."
        ),
        "Sacred Restoration": (
            "The Saintess is preparing Sacred Restoration for next turn."
        ),
        "Purify": (
            "The Saintess is preparing Purify for next turn."
        ),
        "Divine Barrier": (
            "The Saintess is preparing Divine Barrier for next turn."
        ),
    }

    print("\nThe Saintess prepares her next move:")
    print(
        messages.get(
            action_name,
            f"The Saintess is preparing {action_name} for next turn."
        )
    )

def apply_saintess_attack(player, saintess, action, player_dodged):
    action_type = action["type"]

    if action_type == "heal":
        saintess.last_action_type = "heal"
        healed = saintess.use_heal()

        if healed > 0:
            print(
                f"The Saintess restores {healed} health."
            )
        else:
            print(
                "The Saintess's prayer fades without restoring any health."
            )

        return

    if action_type == "purify":
        saintess.last_action_type = "purify"
        if saintess.purify():
            print(
                "The Saintess purifies the poison from her body."
            )
        else:
            print(
                "Holy light passes over the Saintess, but there is no poison to clear."
            )

        return

    if action_type == "barrier":
        saintess.last_action_type = "barrier"
        saintess.activate_barrier()
        print(
            "The Saintess surrounds herself with a Divine Barrier."
        )
        return

    saintess.last_action_type = "attack"

    if player_dodged:
        return

    damage = roll_damage(
        action["damage_min"],
        action["damage_max"]
    )

    gown_before = player.gown_protection
    health_before = player.health

    player.take_damage(damage)

    gown_damage = gown_before - player.gown_protection
    health_damage = health_before - player.health
    total_damage = gown_damage + health_damage

    saintess.record_damage_dealt(total_damage)

    print(
        f"The Saintess uses {action['name']} "
        f"for {damage} damage."
    )

    if gown_damage > 0:
        print(
            f"The Royal Gown absorbs {gown_damage} damage."
        )

    if player.gown_broken and gown_before > 0:
        print(
            "The Royal Gown's protection breaks."
        )

    if health_damage > 0:
        print(
            f"You suffer {health_damage} health damage."
        )

    if player.defense_potion_turns > 0:
        print(
            "The Defense Potion reduces the attack's damage."
        )
        player.reduce_temporary_effects()


def process_poison_turn(player, saintess):
    if saintess.poison_turns <= 0:
        return

    damage = saintess.process_poison()

    if damage > 0:
        player.record_damage_dealt(damage)
        print(
            f"\nPoison deals {damage} damage to the Saintess."
        )

        if saintess.poison_turns > 0:
            print(
                f"Poison remains active for "
                f"{saintess.poison_turns} more turn(s)."
            )
        else:
            print(
                "The poison effect has ended."
            )


def reduce_player_cooldowns(player, turn_number):
    if turn_number > 1:
        player.reduce_cooldowns()


def process_player_action(
    choice,
    player,
    saintess,
    saintess_action
):

    player_dodged = False

    if choice == "1":
        use_normal_attack(player, saintess)
        return True, False

    if choice == "2":
        completed = use_special_attack(
            player,
            saintess
        )
        return completed, False

    if choice == "3":
        if saintess_action["type"] in {
            "heal",
            "purify",
            "barrier"
        }:
            print(
                "You keep your distance and prepare for whatever comes next."
            )
            return True, False

        player_dodged = attempt_dodge(
            player,
            saintess_action
        )

        if player_dodged:
            counter_damage = roll_damage(
                DODGE_COUNTER_MIN,
                DODGE_COUNTER_MAX
            )
            if player.has_item("poisoned dagger"):
                print(
                    "You spot an opening and counter with the Poisoned Dagger."
                )
            else:
                print(
                    "You spot an opening and counterattack."
                )
            apply_player_attack(player, saintess, counter_damage)

        return True, player_dodged

    if choice == "4":
        activated = activate_amulet(player)
        if activated:
            print("The amulet glows, leaving you free to choose another action.")
        return False, False

    if choice == "5":
        used = use_player_potion(player)
        if used:
            print("You drink the potion and remain ready to act.")
        return False, False

    if choice == "6":
        completed = use_grimoire(player)
        return completed, False

    return False, False


def display_battle_summary(player, saintess, turn_number):
    print("\n" + "=" * 55)
    print("BATTLE SUMMARY")
    print("=" * 55)
    print(f"Turns: {turn_number}")
    print(f"Damage Dealt: {player.damage_dealt}")
    print(f"Health Damage Taken: {player.damage_taken}")
    print(f"Health Restored: {player.healing_received}")
    print(f"Successful Dodges: {player.successful_dodges}")
    print(f"Failed Dodges: {player.failed_dodges}")
    print(
        "Royal Gown Protection Remaining: "
        f"{player.gown_protection}"
    )
    print(
        "Saintess Healing Received: "
        f"{saintess.healing_received}"
    )
    print("=" * 55)


def wait_before_close():
    try:
        input("\nPress Enter to close the game...")
    except (EOFError, KeyboardInterrupt):
        pass


def battle_start(player=None):
    if player is None:
        player = Player()

        player.add_item("poisoned dagger")
        player.add_item("royal gown")
        player.add_item("enchanted amulet")
        player.add_item("crown sigil")
        player.add_item("grimoire of restoration")
        player.choose_potion("health potion")

    saintess = Saintess()
    turn_number = 1

    display_battle_intro()

    while player.alive and saintess.alive:
        reduce_player_cooldowns(
            player,
            turn_number
        )

        process_poison_turn(player, saintess)

        if not saintess.alive:
            break

        saintess.update_phase()

        saintess_action = choose_saintess_action(
            saintess
        )

        display_battle_status(
            player,
            saintess,
            turn_number
        )

        telegraph_saintess_action(
            saintess_action
        )

        action_completed = False
        player_dodged = False

        while not action_completed:
            display_player_actions(player)
            choice = get_player_action()

            action_completed, player_dodged = (
                process_player_action(
                    choice,
                    player,
                    saintess,
                    saintess_action
                )
            )

        if not saintess.alive:
            break

        apply_saintess_attack(
            player,
            saintess,
            saintess_action,
            player_dodged
        )

        if player.alive and saintess.alive:
            turn_number += 1

    if saintess.alive is False:
        print(
            "\nThe Saintess falls as her holy light fades."
        )
        print(
            "With your final rival defeated, nothing now "
            "stands between you and the imperial crown."
        )
        print(
            "You have defeated the Saintess. YOU WIN!"
        )

        display_battle_summary(
            player,
            saintess,
            turn_number
        )
        wait_before_close()
        return True

    print(
        "\nThe Saintess's holy power overwhelms you."
    )
    print(
        "Your plan to become Empress ends in the throne room."
    )
    print("GAME OVER.")

    display_battle_summary(
        player,
        saintess,
        turn_number
    )
    wait_before_close()
    return False


if __name__ == "__main__":
    battle_start()