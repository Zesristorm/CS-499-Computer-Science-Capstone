from battle import battle_start
from characters import Player
from items import POTIONS
from tasks import TASKS, run_room_task
from world import process_move


def display_instructions():
    print("\nWelcome to the Villainess Text Adventure.")
    print(
        "Explore the imperial castle, earn useful equipment, and prepare "
        "to confront the Saintess."
    )
    print("\nCommands:")
    print("  north / south / east / west")
    print("  challenge")
    print("  potion")
    print("  inventory")
    print("  map")
    print("  help")
    print("  quit")


def display_map():
    print("\n" + "=" * 67)
    print("IMPERIAL CASTLE MAP")
    print("=" * 67)
    print(
        """
                    Moonflower Conservatory
                              |
                              |
Hall of Champions ---- Imperial Gallery ---- Imperial Wardrobe
        |                                         |
        |                                         |
Alchemy Atelier ----- Sacred Library ----- Imperial Archives
                           |
                           |
                    Grand Throne Room
        """
    )
    print("=" * 67)


def display_inventory(player):
    print("\nInventory:")
    if player.inventory:
        for item in sorted(player.inventory):
            print(f"  - {item.title()}")
    else:
        print("  No equipment collected.")

    if player.selected_potion:
        print(f"  - {player.selected_potion.title()}")
    else:
        print("  - No potion selected")


def show_status(current_room, player):
    print("\n" + "-" * 45)
    print(f"Location: {current_room.title()}")

    if current_room in TASKS:
        reward = TASKS[current_room]["reward"]
        if reward not in player.inventory:
            print(f"Challenge available: {TASKS[current_room]['name']}")
            print(f"Reward: {reward.title()}")

    if current_room == "alchemy atelier" and player.selected_potion is None:
        print("Three prepared potions rest on the alchemist's table.")

    if current_room == "grand throne room":
        print("The Saintess waits beneath the imperial crest.")


def attempt_room_challenge(current_room, player):
    if current_room not in TASKS:
        print("There is no challenge in this room.")
        return

    reward = TASKS[current_room]["reward"]
    if reward in player.inventory:
        print(f"You already collected the {reward.title()}.")
        return

    if run_room_task(current_room, player.completed_tasks):
        player.add_item(reward)
        print(f"You obtained the {reward.title()}.")


def choose_potion(player):
    if player.selected_potion is not None:
        print(f"You already selected the {player.selected_potion.title()}.")
        return

    print("\nYou may take only one potion:")
    print(f"1. Health Potion — {POTIONS['health potion']['description']}")
    print(f"2. Defense Potion — {POTIONS['defense potion']['description']}")
    print(f"3. Poison Potion — {POTIONS['poison potion']['description']}")
    print("4. Leave without choosing")

    choices = {
        "1": "health potion",
        "2": "defense potion",
        "3": "poison potion",
    }

    while True:
        choice = input("Choose your potion: ").strip()
        if choice == "4":
            print("You leave the potions where they are.")
            return

        potion_name = choices.get(choice)
        if potion_name is None:
            print("Choose a number from 1 through 4.")
            continue

        player.choose_potion(potion_name)
        print(f"You selected the {potion_name.title()}.")
        return


def confirm_battle(player):
    print("\nThe Crown Sigil responds to your touch.")
    print("The holy seal parts, revealing the Grand Throne Room.")

    missing_items = {
        "poisoned dagger",
        "royal gown",
        "enchanted amulet",
        "grimoire of restoration",
    } - player.inventory

    if missing_items or player.selected_potion is None:
        print("\nYou are missing optional battle resources:")
        for item in sorted(missing_items):
            print(f"  - {item.title()}")
        if player.selected_potion is None:
            print("  - Chosen Potion")

    while True:
        answer = input(
            "\nEnter the throne room and confront the Saintess? (yes/no): "
        ).strip().lower()
        if answer in {"yes", "y"}:
            return True
        if answer in {"no", "n"}:
            print("You step back from the throne room entrance.")
            return False
        print("Please enter yes or no.")


def reset_player_for_battle(player):
    player.health = player.max_health
    player.alive = True

    if player.has_item("royal gown"):
        player.gown_protection = player.max_gown_protection
        player.gown_broken = False
    else:
        player.gown_protection = 0
        player.gown_broken = True

    player.dagger_special_cooldown = 0
    player.amulet_cooldown = 0
    player.grimoire_cooldown = 0
    player.amulet_active = False
    player.amulet_effect = None
    player.defense_potion_turns = 0
    player.poison_potion_active = False
    player.potion_used = False
    player.successful_dodges = 0
    player.failed_dodges = 0
    player.damage_dealt = 0
    player.damage_taken = 0
    player.healing_received = 0


def main():
    player = Player()
    current_room = "imperial gallery"

    display_instructions()
    display_map()

    while True:
        show_status(current_room, player)

        try:
            command = input("\nEnter a command: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nYou abandon your plan and leave the castle.")
            break

        if command == "quit":
            print("You leave the castle before completing your plan.")
            break

        if command == "help":
            display_instructions()
            continue

        if command == "map":
            display_map()
            continue

        if command == "inventory":
            display_inventory(player)
            continue

        if command in {"challenge", "task"}:
            attempt_room_challenge(current_room, player)
            continue

        if command in {"potion", "choose potion", "get potion"}:
            if current_room == "alchemy atelier":
                choose_potion(player)
            else:
                print("There are no potions to choose from here.")
            continue

        directions = {"north", "south", "east", "west"}
        if command in directions or command.startswith("go "):
            direction = command[3:].strip() if command.startswith("go ") else command
            previous_room = current_room
            next_room = process_move(current_room, direction, player.inventory)

            if next_room == "grand throne room":
                if confirm_battle(player):
                    current_room = next_room
                    show_status(current_room, player)
                    reset_player_for_battle(player)
                    battle_start(player)
                    break
                current_room = previous_room
            else:
                current_room = next_room
            continue

        print("Invalid command. Type 'help' to view the command list.")


if __name__ == "__main__":
    main()
